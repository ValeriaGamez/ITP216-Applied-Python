# Valeria Gamez, vgamez@usc.edu
# ITP 216, Fall 2023
# Section: 32080
# Lab 7
# Description:
#

# 1. Write a decorator function validator_decorator which will validate the decorated function's input:
# a. All the decorated function's args should be strings.
    # b. All the decorated function's kwargs values should be dictionaries with two key:value pairs.
    # c. Display a message informing the user of whether or not the decorated function's arguments pass the test.
def validator_decorator(func):
    print("Testing arguments")
    def wrapper(*args, **kwargs):
        all_good = True
        for arg in args:
            if type(arg) != str:
                all_good = False
                print("\tArguments rejected: not all args are strings.")
        if all_good:
            for kwarg in kwargs.values():
                if type(kwarg) != dict:
                    all_good = False
                    print("\tArguments rejected: not all kwargs are dictionaries")
        if all_good:
            for value in kwargs.values():
                if len(value) != 2:
                    all_good = False
                    print("\tArguments rejected: not all kwargs have two key:value pairs")
        if all_good:
            print("\tArguments accepted: all args are Strings, and all kwargs are dictionaries with two k:v pairs.")
        print("Printing args:")
        for arg in args:
            print('\t' + str(arg))
        print("Printing kwargs:")
        for k,v in kwargs.items():
            print('\t' + str(k) + ": " + str(v))
        print("Running function:")
        func(*args, **kwargs)

    return wrapper


# 2. Write a function to be decorated called print_all_the_things() which prints out the args all on one line, and
# the kwargs' key:value pairs on separate, indented lines. You will use this to test your validator decorator.
@validator_decorator
def print_all_the_things(*args, **kwargs):
    print("This will print all the things:")
    print("\t", end='')
    for arg in args:
        print(str(arg), end=' ')
    print()
    for value in kwargs.values():
        for k, v in value.items():
            print("\t", str(k) + ": " + str(v))


# 3. Decorate the function from #2 with the decorator from #1.
def main():
    print_all_the_things("Another", "lab", "involving", "animals.",
                         animal={'cat': True, 'dog': False},
                         plants={'weed': True, 'flower': False})

    print_all_the_things("Never", "eat", "shredded", "wheat.",
                         animal={'cat': True, 'dog': False, 'hamster': True},
                         plants={'weed': True, 'flower': False})

    print_all_the_things("Never", "eat", "shredded", 4,
                         animal={'cat': True, 'dog': False},
                         plants={'weed': True, 'flower': False})

if __name__ == '__main__':
    main()